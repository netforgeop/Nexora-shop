<?php
/**
 * Variation add-to-cart row.
 *
 * @package Nexora
 * @version 7.0.1
 */

defined( 'ABSPATH' ) || exit;

global $product;
?>
<div class="woocommerce-variation single_variation variant__summary"></div>
<div class="woocommerce-variation-add-to-cart variations_button buy-box__row">
	<?php do_action( 'woocommerce_before_add_to_cart_button' ); ?>
	<?php
	do_action( 'woocommerce_before_add_to_cart_quantity' );
	woocommerce_quantity_input(
		array(
			'min_value'   => apply_filters( 'woocommerce_quantity_input_min', $product->get_min_purchase_quantity(), $product ),
			'max_value'   => apply_filters( 'woocommerce_quantity_input_max', $product->get_max_purchase_quantity(), $product ),
			'input_value' => isset( $_POST['quantity'] ) ? wc_stock_amount( wp_unslash( $_POST['quantity'] ) ) : $product->get_min_purchase_quantity(), // phpcs:ignore WordPress.Security.NonceVerification.Missing
		)
	);
	do_action( 'woocommerce_after_add_to_cart_quantity' );
	?>
	<button type="submit" class="single_add_to_cart_button btn btn--primary btn--lg" data-add-to-cart-submit><?php nexora_the_icon( 'cart-add', 'sm' ); ?><span><?php echo esc_html( $product->single_add_to_cart_text() ); ?></span></button>
	<button type="submit" class="btn btn--dark btn--lg" data-buy-now formaction="<?php echo esc_url( add_query_arg( 'nexora_buy_now', '1', $product->get_permalink() ) ); ?>"><?php nexora_the_icon( 'cash-dollar', 'sm' ); ?><span><?php esc_html_e( 'Buy now', 'nexora' ); ?></span></button>
	<?php do_action( 'woocommerce_after_add_to_cart_button' ); ?>
	<input type="hidden" name="add-to-cart" value="<?php echo absint( $product->get_id() ); ?>" />
	<input type="hidden" name="product_id" value="<?php echo absint( $product->get_id() ); ?>" />
	<input type="hidden" name="variation_id" class="variation_id" value="0" />
</div>
