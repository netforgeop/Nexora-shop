<?php
/**
 * Terms checkbox.
 *
 * @package Nexora
 * @version 3.4.0
 */

defined( 'ABSPATH' ) || exit;

if ( apply_filters( 'woocommerce_checkout_show_terms', true ) && function_exists( 'wc_terms_and_conditions_checkbox_enabled' ) ) {
	do_action( 'woocommerce_checkout_before_terms_and_conditions' );
	?>
	<div class="woocommerce-terms-and-conditions-wrapper checkout-terms">
		<?php do_action( 'woocommerce_checkout_terms_and_conditions' ); ?>
		<?php if ( wc_terms_and_conditions_checkbox_enabled() ) : ?>
			<div class="form-group validate-required">
				<label class="check woocommerce-form__label-for-checkbox">
					<input type="checkbox" class="check__input woocommerce-form__input-checkbox input-checkbox" name="terms" <?php checked( apply_filters( 'woocommerce_terms_is_checked_default', isset( $_POST['terms'] ) ), true ); // phpcs:ignore WordPress.Security.NonceVerification.Missing ?> id="terms" />
					<span class="check__box"></span>
					<span class="check__label woocommerce-terms-and-conditions-checkbox-text"><?php wc_terms_and_conditions_checkbox_text(); ?></span>&nbsp;<span class="req">*</span>
				</label>
				<input type="hidden" name="terms-field" value="1" />
			</div>
		<?php endif; ?>
	</div>
	<?php
	do_action( 'woocommerce_checkout_after_terms_and_conditions' );
}
